public class CalculadorFrete {

    public void calcularFrete(RegraFrete regraFrete, Double peso, String cep){
        regraFrete.calcular(peso, cep);
    }

}
