public class FreteFedex implements RegraFrete{
    @Override
    public void calcular(Double peso, String cep) {
        System.out.println("Frete por fedex");
    }
}
