public class FreteDrone implements RegraFrete{
    @Override
    public void calcular(Double peso, String cep) {
        System.out.println("Frete por Drone");
    }
}
