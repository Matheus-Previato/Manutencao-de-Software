public class Notificacao {
    public Notificacao() {
    }

    public void notificar(String email){
        System.out.println("Email enviado com sucesso para "+email);
    }
}
