//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //Aluno aluno = new Aluno("000.000.000-00","João");
        //CadastroAlunoService cadastroAlunoService = new CadastroAlunoService();
        //cadastroAlunoService.validarCpf(aluno);
        //cadastroAlunoService.salvar(aluno);
        //cadastroAlunoService.notificar(aluno);

        CalculadorFrete calculadorFrete = new CalculadorFrete();

        calculadorFrete.calcularFrete(new FreteDrone(),  0.0, "");
    }
}