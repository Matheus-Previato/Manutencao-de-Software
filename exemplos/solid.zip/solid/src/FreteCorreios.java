public class FreteCorreios implements RegraFrete{
    @Override
    public void calcular(Double peso, String cep) {
        System.out.println("Frete por correios");
    }
}
