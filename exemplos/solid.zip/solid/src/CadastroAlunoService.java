public class CadastroAlunoService {
    public CadastroAlunoService() {
    }
    
    public void cadastrar(Aluno aluno){
        ValidarAluno validarAluno = new ValidarAluno();
        validarAluno.validarCpf(aluno);
        Notificacao notificacao = new Notificacao();
        notificacao.notificar("ze@gmail.com");
    }
    

    public void salvar(Aluno aluno){
        System.out.println("Aluno salvo com sucesso!");
    }
}
