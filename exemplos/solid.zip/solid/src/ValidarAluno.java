public class ValidarAluno {
    public ValidarAluno() {
    }

    public void validarCpf(Aluno aluno){
        if (aluno.getCpf().equals("000.000.000-00")){
            System.out.println("CPF válido");
        } else {
            System.out.println("CPF Inválido.");
        }
    }
}
