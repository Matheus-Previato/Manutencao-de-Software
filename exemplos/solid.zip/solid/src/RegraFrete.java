public interface RegraFrete {
    public void calcular(Double peso, String cep);
}
